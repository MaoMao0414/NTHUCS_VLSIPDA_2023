#ifndef NET_H_DEF
#define NET_H_DEF

struct Net
{
    std::string module1Name, module2Name;
    long long weight;
};

#endif